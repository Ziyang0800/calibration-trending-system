"""
test_stability_specs.py - validates the interpolation/extrapolation math
against hand-computed values for each distinct spec shape in use.
"""

import pytest

from stability_specs import get_stability_allowance, assess_drift, DAYS_PER_MONTH


def months(n):
    return n * DAYS_PER_MONTH


def test_exact_checkpoints_match_published_values():
    # 742A-1: 6 months -> 5ppm, 12 months -> 8ppm (given directly, no interpolation needed)
    assert get_stability_allowance("742A-1", months(6)) == pytest.approx(5.0, abs=1e-6)
    assert get_stability_allowance("742A-1", months(12)) == pytest.approx(8.0, abs=1e-6)


def test_interpolation_within_a_segment():
    # 742A-1: halfway between 6mo (5ppm) and 12mo (8ppm) -> 6.5ppm
    assert get_stability_allowance("742A-1", months(9)) == pytest.approx(6.5, abs=1e-6)
    # first segment: halfway between 0mo (0ppm) and 6mo (5ppm) -> 2.5ppm
    assert get_stability_allowance("742A-1", months(3)) == pytest.approx(2.5, abs=1e-6)


def test_extrapolation_beyond_last_checkpoint_uses_final_segment_slope():
    # 742A-1: slope from 6mo->12mo is (8-5)/6 = 0.5ppm/month
    # at 18 months (6 months past the last checkpoint): 8 + 0.5*6 = 11ppm
    assert get_stability_allowance("742A-1", months(18)) == pytest.approx(11.0, abs=1e-6)


def test_single_checkpoint_is_a_constant_rate():
    # L&N 4221B: +-10ppm/year, single checkpoint at 12mo -> constant rate through origin
    assert get_stability_allowance("L&N 4221B", months(6)) == pytest.approx(5.0, abs=1e-6)
    assert get_stability_allowance("L&N 4221B", months(12)) == pytest.approx(10.0, abs=1e-6)
    assert get_stability_allowance("L&N 4221B", months(24)) == pytest.approx(20.0, abs=1e-6)  # extrapolated


def test_two_tier_year_based_spec():
    # 9334A-0.1: initial 12mo +-2.5ppm, second year +-2ppm more (cumulative 4.5 at 24mo)
    assert get_stability_allowance("9334A-0.1", months(12)) == pytest.approx(2.5, abs=1e-6)
    assert get_stability_allowance("9334A-0.1", months(24)) == pytest.approx(4.5, abs=1e-6)
    # our real cal interval is ~6 months -> half of the first-year tier
    assert get_stability_allowance("9334A-0.1", months(6)) == pytest.approx(1.25, abs=1e-6)


def test_alias_model_name_matches_same_spec():
    # "9334-0.1" (no A) is the same physical model as "9334A-0.1" in our real data
    assert get_stability_allowance("9334-0.1", months(6)) == get_stability_allowance("9334A-0.1", months(6))


def test_explicit_ongoing_rate_override_esi_sr104():
    # ESI SR104: 1ppm/year for first 2 years (2ppm cumulative at 24mo), then
    # an EXPLICIT 0.5ppm/year "thereafter" - this must NOT equal the rate
    # implied by extrapolating the 0-24mo segment (which would be 1ppm/year).
    assert get_stability_allowance("ESI SR104", months(24)) == pytest.approx(2.0, abs=1e-6)
    # 12 months past the 24mo checkpoint, at the explicit 0.5ppm/year rate: 2 + 0.5 = 2.5ppm
    assert get_stability_allowance("ESI SR104", months(36)) == pytest.approx(2.5, abs=1e-6)
    # sanity check this is NOT the naive (wrong) extrapolation of the first segment's slope
    naive_wrong = 2.0 + (2.0 / 24.0) * 12  # would be 3.0 if the override weren't applied
    assert get_stability_allowance("ESI SR104", months(36)) != pytest.approx(naive_wrong, abs=1e-6)


def test_unknown_model_returns_none():
    assert get_stability_allowance("Some Unlisted Model", months(6)) is None


def test_assess_drift_within_spec():
    result = assess_drift("742A-1", observed_drift_ppm=3.0, elapsed_days=months(6))
    assert result["allowance_ppm"] == pytest.approx(5.0, abs=1e-6)
    assert result["exceeds"] is False


def test_assess_drift_exceeds_spec():
    result = assess_drift("742A-1", observed_drift_ppm=7.0, elapsed_days=months(6))
    assert result["allowance_ppm"] == pytest.approx(5.0, abs=1e-6)
    assert result["exceeds"] is True


def test_assess_drift_uses_absolute_value_of_drift():
    # a NEGATIVE drift of the same magnitude should be judged the same way
    result = assess_drift("742A-1", observed_drift_ppm=-7.0, elapsed_days=months(6))
    assert result["exceeds"] is True


def test_assess_drift_unknown_model_is_not_assessable():
    result = assess_drift("Unlisted Model", observed_drift_ppm=100.0, elapsed_days=months(6))
    assert result["allowance_ppm"] is None
    assert result["exceeds"] is None


def test_all_twelve_models_from_the_spec_sheet_are_present():
    expected = [
        "9334A-0.1", "L&N 4221B", "742A-1", "742A-10", "742A-100", "742A-1K",
        "ESI SR104", "742A-100K", "742A-1M", "742A-10M", "9334A-1G", "9334A-100M",
    ]
    from stability_specs import STABILITY_SPECS
    for model in expected:
        assert model in STABILITY_SPECS, f"{model} missing from STABILITY_SPECS"
