"""
app.py - Phase 4 dashboard.

Run with:
    python app.py
Then open http://127.0.0.1:5000 in a browser (or let it open automatically).

Reads from the SQLite database built in Phase 2 (default: calibration.db,
next to this file/exe - override with --db).

Path handling below matters once this is packaged as CalibrationSystem.exe
(Phase 6): PyInstaller extracts bundled files (this script, templates/) to
a TEMP folder that's deleted when the app closes, so calibration.db and
any Excel exports must be anchored to the .exe's own folder (sys.executable),
never to that temp extraction path or to the current working directory
(which isn't reliable when double-clicked from Explorer).
"""

import argparse
import io
import os
import re
import shutil
import sys
import threading
import time
import uuid
import webbrowser
import zipfile
from datetime import date, datetime

from flask import Flask, render_template, send_file, abort, redirect, url_for, request

from db import connect, update_asset, delete_asset, get_calibration, update_calibration, delete_calibration, insert_calibration
from queries import list_assets_grouped_by_set, get_asset_detail
from export_excel import export_all_assets, export_single_asset
from report_pdf import generate_report
from htbasic_export import SET_STATION_MAPPING, ZERO_POINT_ONE_OHM_OPTIONS, validate_required_resistors, \
    generate_all_files
from cal_cert_importer import extract_serial_and_date, extract_measurement, logger as cert_logger, _setup_logging


def resource_path(relative: str) -> str:
    """Where bundled files (templates/, static/) actually live - the temp
    PyInstaller extraction dir when frozen, this script's folder otherwise."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


def app_dir() -> str:
    """Where USER DATA (the database, exports) should live - always next to
    the .exe itself (or this script), never the temp extraction folder."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


app = Flask(__name__, template_folder=resource_path("templates"), static_folder=resource_path("static"))
app.config["DB_PATH"] = os.path.join(app_dir(), "calibration.db")
EXPORTS_DIR = os.path.join(app_dir(), "exports")
REPORTS_DIR = os.path.join(app_dir(), "reports")
CERTS_DIR = os.path.join(app_dir(), "certs")
ATTACHMENTS_DIR = os.path.join(app_dir(), "attachments")
PENDING_DIR = os.path.join(app_dir(), "pending_imports")
os.makedirs(CERTS_DIR, exist_ok=True)
os.makedirs(ATTACHMENTS_DIR, exist_ok=True)
os.makedirs(PENDING_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)
_setup_logging()  # shares the same log file cal_cert_importer.py's CLI path uses


def _decimals_for(nominal: float) -> int:
    """More decimals for small nominals, fewer for large ones - keeps every
    row showing about the same number of significant figures instead of a
    fixed decimal count that's excessive for 1 GOhm and too coarse for 0.1 Ohm."""
    integer_digits = len(str(abs(int(nominal)))) if abs(nominal) >= 1 else 1
    return max(0, 9 - integer_digits)


@app.template_filter("ohms")
def format_ohms(value):
    """Compact nominal-value formatting: whole numbers get thousands
    separators and no trailing '.0'; fractional ones print as-is."""
    if value is None:
        return "—"
    if float(value) == int(value):
        return f"{int(value):,}"
    return f"{value:g}"


@app.template_filter("measured")
def format_measured(value, nominal=None):
    if value is None:
        return "—"
    decimals = _decimals_for(nominal) if nominal is not None else 9
    return f"{value:,.{decimals}f}"


@app.template_filter("basename")
def format_basename(path):
    if not path:
        return ""
    return os.path.basename(path)


def get_conn():
    return connect(app.config["DB_PATH"])


@app.route("/")
def dashboard():
    conn = get_conn()
    sets = list_assets_grouped_by_set(conn)
    conn.close()

    total = sum(s["total"] for s in sets)
    ok_count = sum(s["ok_count"] for s in sets)
    out_count = sum(s["out_count"] for s in sets)
    insufficient_count = sum(s["insufficient_count"] for s in sets)

    return render_template(
        "dashboard.html", sets=sets, total=total,
        ok_count=ok_count, out_count=out_count, insufficient_count=insufficient_count,
    )


@app.route("/assets/<int:asset_id>")
def asset_detail(asset_id):
    conn = get_conn()
    detail = get_asset_detail(conn, asset_id)
    conn.close()
    if detail is None:
        abort(404)
    return render_template("asset_detail.html", **detail)


@app.route("/certs/<int:calibration_id>")
def view_certificate(calibration_id):
    conn = get_conn()
    row = conn.execute("SELECT cert_pdf_path FROM calibrations WHERE id = ?", (calibration_id,)).fetchone()
    conn.close()
    if row is None or row[0] is None or not os.path.exists(row[0]):
        abort(404, "No certificate PDF on file for this calibration.")
    return send_file(row[0], mimetype="application/pdf")


@app.route("/calibrations/<int:calibration_id>/comment")
def calibration_comment(calibration_id):
    conn = get_conn()
    cal = get_calibration(conn, calibration_id)
    asset = None
    if cal is not None:
        asset_row = conn.execute("SELECT serial, model FROM assets WHERE id = ?", (cal["asset_id"],)).fetchone()
        asset = {"serial": asset_row[0], "model": asset_row[1]} if asset_row else None
    conn.close()
    if cal is None:
        abort(404)
    return render_template("calibration_comment.html", cal=cal, asset=asset)


@app.route("/calibrations/<int:calibration_id>/attachment")
def view_attachment(calibration_id):
    conn = get_conn()
    cal = get_calibration(conn, calibration_id)
    conn.close()
    path = cal["reviewer_attachment_path"] if cal else None
    if not path or not os.path.exists(path):
        abort(404, "No attachment on file for this calibration.")
    return send_file(path, as_attachment=False)


@app.route("/export/asset/<int:asset_id>")
def export_asset(asset_id):
    conn = get_conn()
    path = export_single_asset(conn, asset_id, out_dir=EXPORTS_DIR)
    conn.close()
    if path is None:
        abort(404)
    return send_file(path, as_attachment=True)


@app.route("/export/all")
def export_all():
    conn = get_conn()
    path = export_all_assets(conn, out_dir=EXPORTS_DIR)
    conn.close()
    return send_file(path, as_attachment=True)


@app.route("/report/generate", methods=["POST"])
def report_generate():
    asset_ids = [int(i) for i in request.form.getlist("asset_ids")]
    conn = get_conn()
    if not asset_ids:
        asset_ids = [r[0] for r in conn.execute("SELECT id FROM assets ORDER BY source_sheet, serial")]
    path = os.path.join(REPORTS_DIR, f"calibration_report_{datetime.now():%Y%m%d_%H%M%S}.pdf")
    generate_report(conn, asset_ids, path)
    conn.close()
    return send_file(path, as_attachment=True)


# ---------------------------------------------------------------- HTBasic legacy files

@app.route("/htbasic")
def htbasic_form():
    return render_template(
        "htbasic_form.html",
        set_options=list(SET_STATION_MAPPING.keys()),
        zero_pt_one_options=ZERO_POINT_ONE_OHM_OPTIONS,
        problems=None, set_name=None, zero_pt_one_pn=None,
    )


@app.route("/htbasic/generate", methods=["POST"])
def htbasic_generate():
    set_name = request.form["set_name"]
    zero_pt_one_pn = request.form["zero_pt_one_pn"]

    conn = get_conn()
    problems = validate_required_resistors(conn, set_name, zero_pt_one_pn)
    if problems:
        conn.close()
        return render_template(
            "htbasic_form.html",
            set_options=list(SET_STATION_MAPPING.keys()),
            zero_pt_one_options=ZERO_POINT_ONE_OHM_OPTIONS,
            problems=problems, set_name=set_name, zero_pt_one_pn=zero_pt_one_pn,
        )

    files = generate_all_files(conn, set_name, zero_pt_one_pn)
    conn.close()

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for filename, content in files.items():
            zf.writestr(filename, content.encode("ascii"))
    buf.seek(0)

    station = SET_STATION_MAPPING[set_name]["station"].replace(" ", "")
    zip_name = f"htbasic_{set_name.replace(' ', '')}_{station}_{datetime.now():%Y%m%d_%H%M%S}.zip"
    return send_file(buf, as_attachment=True, download_name=zip_name, mimetype="application/zip")


# ---------------------------------------------------------------- Import certificate

@app.route("/import", methods=["GET"])
def import_form():
    return render_template("import.html", error=None)


def _parse_one_cert(uploaded, conn) -> dict:
    """Parses a single uploaded cert file. Returns a dict with 'ok': True
    always, EXCEPT when the file itself can't even be opened as a PDF
    (corrupt file, encrypted PDF, not actually a PDF) - that's the one
    case nothing can be manually entered to fix, so it's still a hard
    failure. Every other recognition failure (serial, date, measured
    value, or MU couldn't be read) is instead recorded in 'needs_manual'
    and left for the reviewer to fill in on the review page - the row
    still gets a temp file and can still be imported once corrected."""
    original_filename = uploaded.filename
    token = uuid.uuid4().hex
    temp_path = os.path.join(PENDING_DIR, f"{token}.pdf")
    uploaded.save(temp_path)

    try:
        id_fields = extract_serial_and_date(temp_path)
    except Exception as e:
        os.remove(temp_path)
        cert_logger.error("Web import: exception reading %s: %s", original_filename, e)
        return {"ok": False, "filename": original_filename,
                "error": f"Couldn't open this file as a PDF ({e}). Is it actually a PDF certificate?"}

    serial = id_fields.get("serial")
    cal_date = id_fields["cal_date"].date().isoformat() if id_fields.get("cal_date") else None

    asset = None
    if serial:
        asset_row = conn.execute(
            "SELECT id, serial, model, asset_number, nominal_ohms, source_sheet FROM assets WHERE serial = ?",
            (serial,),
        ).fetchone()
        if asset_row:
            asset = {
                "id": asset_row[0], "serial": asset_row[1], "model": asset_row[2],
                "asset_number": asset_row[3], "nominal_ohms": asset_row[4], "source_sheet": asset_row[5],
            }
        else:
            cert_logger.warning("Web import: serial %s not found in database (file %s) - "
                                 "will need manual correction", serial, original_filename)

    known_nominal = asset["nominal_ohms"] if asset else None
    try:
        measurement = extract_measurement(temp_path, known_nominal=known_nominal)
    except Exception as e:
        cert_logger.error("Web import: exception parsing measurement from %s: %s", original_filename, e)
        measurement = {"measured_value": None, "mu_relative": None, "warnings": []}

    for w in measurement.get("warnings", []):
        cert_logger.warning("Web import: %s | serial=%s file=%s", w, serial, original_filename)

    cert_number_m = re.search(r"(WO-\d+)", original_filename)

    needs_manual = []
    if not serial or asset is None:
        needs_manual.append("serial")
    if not cal_date:
        needs_manual.append("cal_date")
    if measurement.get("measured_value") is None:
        needs_manual.append("measured_value")
    if measurement.get("mu_relative") is None:
        needs_manual.append("mu_relative")
    if needs_manual:
        cert_logger.warning("Web import: %s needs manual entry for: %s", original_filename, ", ".join(needs_manual))

    return {
        "ok": True, "filename": original_filename, "token": token, "asset": asset,
        "serial": serial or "", "cal_date": cal_date or "",
        "measured_value": measurement.get("measured_value"), "mu_relative": measurement.get("mu_relative"),
        "warnings": measurement.get("warnings", []),
        "needs_manual": needs_manual,
        "cert_number": cert_number_m.group(1) if cert_number_m else "",
    }


@app.route("/import/parse", methods=["POST"])
def import_parse():
    uploaded_files = [f for f in request.files.getlist("pdfs") if f and f.filename]
    if not uploaded_files:
        return render_template("import.html", error="Choose at least one PDF file first.")

    conn = get_conn()
    results = [_parse_one_cert(f, conn) for f in uploaded_files]
    conn.close()

    return render_template("import_review.html", results=results)


@app.route("/import/confirm", methods=["POST"])
def import_confirm():
    row_count = int(request.form["row_count"])
    conn = get_conn()
    summary = []
    last_asset_id = None

    for i in range(row_count):
        token = request.form.get(f"token_{i}")
        temp_path = os.path.join(PENDING_DIR, f"{token}.pdf") if token else None

        if request.form.get(f"include_{i}") != "on":
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)
            continue

        if not temp_path or not os.path.exists(temp_path):
            summary.append({"filename": request.form.get(f"filename_{i}", f"row {i+1}"),
                             "status": "expired", "detail": "session expired - please re-upload"})
            continue

        filename_display = request.form.get(f"filename_{i}", f"row {i+1}")
        asset_serial = request.form.get(f"serial_{i}", "").strip()
        cal_date_str = request.form.get(f"cal_date_{i}", "").strip()
        measured_str = request.form.get(f"measured_value_{i}", "").strip()
        mu_str = request.form.get(f"mu_relative_{i}", "").strip()
        cert_number = request.form.get(f"cert_number_{i}") or None

        if not (asset_serial and cal_date_str and measured_str and mu_str):
            os.remove(temp_path)
            summary.append({"filename": filename_display, "status": "error",
                             "detail": "one or more required fields were left blank"})
            continue

        asset_row = conn.execute("SELECT id FROM assets WHERE serial = ?", (asset_serial,)).fetchone()
        if asset_row is None:
            os.remove(temp_path)
            summary.append({"filename": filename_display, "status": "error",
                             "detail": f"serial {asset_serial} not found in the database"})
            continue
        asset_id = asset_row[0]

        try:
            measured_value = float(measured_str)
            mu_relative = float(mu_str)
            date.fromisoformat(cal_date_str)  # validates format without needing the parsed value
        except ValueError:
            os.remove(temp_path)
            summary.append({"filename": filename_display, "status": "error",
                             "detail": "couldn't parse the date/measured value/MU entered - check the format"})
            continue

        permanent_name = f"{asset_serial}_{cal_date_str}_{token[:8]}.pdf"
        permanent_path = os.path.join(CERTS_DIR, permanent_name)

        inserted = insert_calibration(
            conn, asset_id, cal_date=cal_date_str, measured_value=measured_value, mu_relative=mu_relative,
            source="pdf_import", cert_number=cert_number, cert_pdf_path=permanent_path,
        )
        if inserted:
            shutil.move(temp_path, permanent_path)
            cert_logger.info("Web import confirmed: serial=%s date=%s measured=%s mu=%s",
                              asset_serial, cal_date_str, measured_value, mu_relative)
            summary.append({"filename": filename_display,
                             "status": "imported", "detail": f"{asset_serial} — {cal_date_str}"})
            last_asset_id = asset_id
        else:
            os.remove(temp_path)
            cert_logger.info("Web import: duplicate skipped serial=%s date=%s", asset_serial, cal_date_str)
            summary.append({"filename": filename_display,
                             "status": "duplicate", "detail": f"{asset_serial} — {cal_date_str} already on file"})

    conn.commit()
    conn.close()

    return render_template("import_result.html", summary=summary, last_asset_id=last_asset_id)


@app.route("/import/cancel", methods=["POST"])
def import_cancel():
    row_count = int(request.form.get("row_count", 1))
    for i in range(row_count):
        token = request.form.get(f"token_{i}") or (request.form.get("token") if i == 0 else None)
        if token:
            temp_path = os.path.join(PENDING_DIR, f"{token}.pdf")
            if os.path.exists(temp_path):
                os.remove(temp_path)
    return redirect(url_for("import_form"))


# ---------------------------------------------------------------- Edit / delete

@app.route("/assets/<int:asset_id>/edit", methods=["GET", "POST"])
def asset_edit(asset_id):
    conn = get_conn()
    if request.method == "POST":
        ok, error = update_asset(
            conn, asset_id,
            serial=request.form["serial"].strip(),
            model=request.form.get("model", "").strip() or None,
            asset_number=request.form.get("asset_number", "").strip() or None,
            nominal_ohms=float(request.form["nominal_ohms"]),
            set_id=request.form.get("set_id", "").strip() or None,
        )
        if ok:
            conn.commit()
            conn.close()
            return redirect(url_for("asset_detail", asset_id=asset_id))
        detail = get_asset_detail(conn, asset_id)
        conn.close()
        return render_template("asset_edit.html", asset=detail["asset"], error=error)

    detail = get_asset_detail(conn, asset_id)
    conn.close()
    if detail is None:
        abort(404)
    return render_template("asset_edit.html", asset=detail["asset"], error=None)


@app.route("/assets/<int:asset_id>/delete", methods=["POST"])
def asset_delete(asset_id):
    conn = get_conn()
    delete_asset(conn, asset_id)
    conn.commit()
    conn.close()
    return redirect(url_for("dashboard"))


@app.route("/calibrations/<int:calibration_id>/edit", methods=["GET", "POST"])
def calibration_edit(calibration_id):
    conn = get_conn()
    if request.method == "POST":
        uploaded = request.files.get("reviewer_attachment")
        attachment_path = None
        keep_existing = True
        if uploaded and uploaded.filename:
            keep_existing = False
            safe_name = f"{calibration_id}_{uuid.uuid4().hex[:8]}_{uploaded.filename}"
            attachment_path = os.path.join(ATTACHMENTS_DIR, safe_name)
            uploaded.save(attachment_path)
        elif request.form.get("remove_attachment") == "on":
            keep_existing = False
            existing = get_calibration(conn, calibration_id)
            if existing and existing["reviewer_attachment_path"] and os.path.exists(existing["reviewer_attachment_path"]):
                os.remove(existing["reviewer_attachment_path"])
            attachment_path = None

        ok, error = update_calibration(
            conn, calibration_id,
            cal_date=request.form["cal_date"],
            measured_value=float(request.form["measured_value"]),
            mu_relative=float(request.form["mu_relative"]),
            reviewer_comment=request.form.get("reviewer_comment", "").strip() or None,
            excluded_from_regression=request.form.get("excluded_from_regression") == "on",
            reviewer_attachment_path=attachment_path,
            keep_existing_attachment=keep_existing,
        )
        cal = get_calibration(conn, calibration_id)
        if ok:
            conn.commit()
            conn.close()
            return redirect(url_for("asset_detail", asset_id=cal["asset_id"]))
        conn.close()
        return render_template("calibration_edit.html", cal=cal, error=error)

    cal = get_calibration(conn, calibration_id)
    conn.close()
    if cal is None:
        abort(404)
    return render_template("calibration_edit.html", cal=cal, error=None)


@app.route("/calibrations/<int:calibration_id>/delete", methods=["POST"])
def calibration_delete(calibration_id):
    conn = get_conn()
    cal = get_calibration(conn, calibration_id)
    if cal is None:
        conn.close()
        abort(404)
    asset_id = cal["asset_id"]
    delete_calibration(conn, calibration_id)
    conn.commit()
    conn.close()
    return redirect(url_for("asset_detail", asset_id=asset_id))


def _open_browser_soon(url: str):
    def _open():
        time.sleep(1.2)
        webbrowser.open(url)
    threading.Thread(target=_open, daemon=True).start()


def _get_lan_ip() -> str:
    """Best-effort guess at this machine's LAN-facing IP address (the one
    other PCs on the network would actually use to reach it) - doesn't
    send any real traffic, just asks the OS which local interface it
    would route through to reach an external address."""
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=None, help="defaults to calibration.db next to this app")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--debug", action="store_true", help="Flask debug mode - forces the dev server, not Waitress")
    ap.add_argument("--no-browser", action="store_true", help="don't auto-open a browser tab")
    ap.add_argument("--network", action="store_true",
                     help="listen on the local network, not just this PC, so colleagues can connect "
                          "via browser (prints the URL to give them)")
    ap.add_argument("--host", default=None, help="advanced: override the listen address directly")
    args = ap.parse_args()

    if args.db:
        app.config["DB_PATH"] = args.db

    host = args.host or ("0.0.0.0" if args.network else "127.0.0.1")
    browser_url = f"http://127.0.0.1:{args.port}"  # always open localhost, regardless of listen host

    print(f"Calibration Trending running at {browser_url}")
    if args.network:
        print(f"Reachable on your network at: http://{_get_lan_ip()}:{args.port}  <- give this URL to colleagues")
        print("(Only people on the same local network can reach this - it is not exposed to the internet.)")
    print(f"Database: {app.config['DB_PATH']}")
    print("Press Ctrl+C in this window to stop.")

    if not args.no_browser:
        _open_browser_soon(browser_url)

    if args.debug:
        # Flask's own dev server, for its debugger/auto-context - not for
        # leaving this running unattended. use_reloader must stay off: under
        # a frozen .exe it would try to re-launch the exe as a subprocess.
        app.run(debug=True, host=host, port=args.port, use_reloader=False)
        return

    try:
        from waitress import serve
        serve(app, host=host, port=args.port)
    except ImportError:
        print("(waitress not installed - falling back to Flask's built-in development server. "
              "Run 'pip install waitress' for a production-grade server suited to staying "
              "running unattended.)")
        app.run(host=host, port=args.port, use_reloader=False)


if __name__ == "__main__":
    main()
