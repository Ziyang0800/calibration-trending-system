"""
migrate_excel_to_sqlite.py - Phase 2 migration.

Scans a trending workbook (any of your 11 decade files) for asset blocks
using the header pattern already confirmed in 0_1_Ohm.xlsx:

    row 1: <blank> | Model | PN/EQ number | Serial Number | <blank> | <blank> | <blank> | "Prediction Interval (95%)" | <blank> | <blank>
    row 2: Date | Since Last Cal [Days] | Accumulated [Days] | Error [PPM] | Drifted [PPM] |
           Measured Value | MU (K =2) | Prediction | Lower | Upper

Each block is exactly 10 columns wide. A block is found by locating a
cell in row 2 whose value is "Date" immediately followed (same row) by
"Since Last Cal [Days]" in the next column - that pair is specific enough
not to false-positive elsewhere in the sheet.

The nominal value isn't stored anywhere in the sheet headers, so it's
parsed from the SHEET (tab) NAME instead, using the same unit-prefix
logic as the PDF importer, e.g. "0.1 Ohm" -> 0.1, "10 kOhm" -> 10000,
"1 MOhm" -> 1_000_000. If your other 10 workbooks name their tabs
differently, see the NOMINAL PARSING note below.

Usage:
    python migrate_excel_to_sqlite.py <workbook.xlsx> [<workbook2.xlsx> ...] [--db calibration.db]

Safe to re-run: calibrations are keyed on (asset, date), so re-migrating
the same workbook (or a workbook you've since appended new certs to)
only inserts genuinely new rows.
"""

import argparse
import re
import sys
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter, column_index_from_string

from db import connect, upsert_asset, insert_calibration

BLOCK_WIDTH = 10
HEADER_ROW2 = ["Date", "Since Last Cal [Days]", "Accumulated [Days]", "Error [PPM]",
               "Drifted [PPM]", "Measured Value", "MU (K =2)", "Prediction", "Lower", "Upper"]

# Same SI-prefix table as cal_cert_importer.py, used here to parse the
# sheet/tab name (e.g. "10 kOhm") into a nominal value in base ohms.
UNIT_MULTIPLIERS = {
    "p": 1e-12, "n": 1e-9, "u": 1e-6, "\u00b5": 1e-6, "m": 1e-3,
    "": 1.0, "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9,
}
_NOMINAL_NAME_RE = re.compile(r"([\d.]+)\s*([pnu\u00b5mkKMG]?)\s*Ohm", re.IGNORECASE)


def parse_nominal_from_sheet_name(sheet_name: str) -> float:
    """
    'NOMINAL PARSING' note: this expects a tab name like "0.1 Ohm", "10 kOhm",
    "1 MOhm". If your other workbooks' tabs are named differently (e.g. just
    "Sheet1", or "10K"), this will fail loudly (see main()) rather than
    guess wrong - fix the tab name or extend this regex, don't silently
    trust a wrong nominal into the database.
    """
    m = _NOMINAL_NAME_RE.search(sheet_name)
    if not m:
        return None
    value, prefix = m.groups()
    return float(value) * UNIT_MULTIPLIERS.get(prefix, 1.0)


def find_blocks(ws):
    """Yields dict of column letters for each asset block found on the sheet."""
    max_col = ws.max_column
    for col_idx in range(1, max_col):
        c1 = ws.cell(row=2, column=col_idx).value
        c2 = ws.cell(row=2, column=col_idx + 1).value
        if c1 == "Date" and c2 == "Since Last Cal [Days]":
            cols = [get_column_letter(col_idx + i) for i in range(BLOCK_WIDTH)]
            # sanity check the rest of the header row matches the known pattern
            actual = [ws[f"{c}2"].value for c in cols]
            if actual != HEADER_ROW2:
                continue
            model = ws[f"{cols[1]}1"].value
            asset_number = ws[f"{cols[2]}1"].value
            serial = ws[f"{cols[3]}1"].value
            yield {
                "cols": dict(zip(
                    ["date", "since", "accum", "error", "drift", "measured", "mu", "pred", "lower", "upper"],
                    cols,
                )),
                "model": str(model) if model is not None else None,
                "asset_number": str(asset_number) if asset_number is not None else None,
                "serial": str(serial) if serial is not None else None,
            }


def migrate_workbook(path: str, db_path: str):
    """
    NOTE on cached formula values: this reads with data_only=True, which
    returns Excel's last-CACHED result for formula cells, not a live
    recalculation (openpyxl can't evaluate formulas itself). Some of your
    MU cells are formulas (e.g. EQ358990's =0.00000061*0.1), not raw
    numbers. If a workbook has been saved by anything other than real
    Excel since it was last opened there (our importer included - it
    uses openpyxl, which does NOT recompute or preserve formula caches),
    those cached values go stale/missing, and this would otherwise
    silently "migrate" 0 rows for that asset instead of erroring.
    To avoid that: before migrating, this checks whether any expected
    value is missing while the underlying cell is actually a formula,
    and aborts with an actionable message rather than under-importing.
    """
    wb_cached = openpyxl.load_workbook(path, data_only=True)
    wb_raw = openpyxl.load_workbook(path, data_only=False)
    conn = connect(db_path)
    total_new = 0

    for ws in wb_cached.worksheets:
        if ws.title == "Asset_Index":
            continue
        ws_raw = wb_raw[ws.title]
        nominal = parse_nominal_from_sheet_name(ws.title)
        blocks = list(find_blocks(ws))
        if not blocks:
            continue
        if nominal is None:
            sys.exit(
                f"Could not parse a nominal value from sheet name '{ws.title}' in {path}. "
                f"See the NOMINAL PARSING note in this script - fix the tab name or extend "
                f"the regex, then re-run."
            )

        for block in blocks:
            if block["serial"] is None:
                continue
            asset_id = upsert_asset(
                conn, serial=block["serial"], model=block["model"],
                asset_number=block["asset_number"], nominal_ohms=nominal,
                source_workbook=Path(path).name, source_sheet=ws.title,
            )

            date_col = block["cols"]["date"]
            measured_col = block["cols"]["measured"]
            mu_col = block["cols"]["mu"]
            row = 3
            block_new = 0
            while ws[f"{date_col}{row}"].value is not None:
                date_val = ws[f"{date_col}{row}"].value
                measured_val = ws[f"{measured_col}{row}"].value
                mu_val = ws[f"{mu_col}{row}"].value

                for label, col, cached in (("measured value", measured_col, measured_val),
                                            ("MU", mu_col, mu_val)):
                    if cached is None:
                        raw = ws_raw[f"{col}{row}"].value
                        if isinstance(raw, str) and raw.startswith("="):
                            sys.exit(
                                f"{path} / {ws.title} / {block['serial']}: row {row}'s {label} "
                                f"({col}{row}) is a formula with no cached value - this happens "
                                f"when the file was last saved by something other than real "
                                f"Excel (e.g. our importer script), which doesn't recompute "
                                f"formulas.\n\nFix: open {path} in Excel, let it recalculate "
                                f"(should happen automatically; press Ctrl+Alt+F9 to force it), "
                                f"save, close, then re-run this migration."
                            )

                if measured_val is not None and mu_val is not None:
                    mu_relative = mu_val / nominal  # sheet stores MU in absolute ohms; DB stores it relative
                    date_str = date_val.date().isoformat() if hasattr(date_val, "date") else str(date_val)
                    if insert_calibration(conn, asset_id, date_str, measured_val, mu_relative,
                                           source="excel_migration"):
                        block_new += 1
                row += 1
            print(f"  {ws.title} / {block['serial']} ({block['asset_number']}): "
                  f"{block_new} new row(s) migrated")
            total_new += block_new

    conn.commit()
    conn.close()
    return total_new


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("workbooks", nargs="+")
    ap.add_argument("--db", default="calibration.db")
    args = ap.parse_args()

    grand_total = 0
    for path in args.workbooks:
        print(f"Migrating {path} ...")
        grand_total += migrate_workbook(path, args.db)

    print(f"\nDone. {grand_total} new calibration row(s) written to {args.db}.")


if __name__ == "__main__":
    main()
