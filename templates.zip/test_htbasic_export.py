"""
test_htbasic_export.py

Validates the HTBasic legacy file generator against real sample files
(tests/fixtures/htbasic/) captured from the actual system. Confirmed
workflow (see chat): Set 1/Station B-1 and Set 2/Station B-2 are a fixed
pairing (one choice, not two) that governs both the 1-Ohm-1GOhm resistors
AND which station file gets written; the 0.1 Ohm resistor for that
station file is a separate, independent choice from all three available.
"""

import sqlite3
from pathlib import Path

import pytest

from db import connect, upsert_asset, insert_calibration
from htbasic_export import (
    generate_resnom, generate_resvalue, generate_highres, generate_onemeg,
    generate_station_file, generate_all_files, validate_required_resistors,
)
from htbasic_format import format_like

FIXTURES = Path(__file__).parent / "fixtures" / "htbasic"


@pytest.fixture
def real_conn():
    """A connection to a copy of the real database, so tests exercise the
    generator against actual production data rather than synthetic stand-ins."""
    import shutil
    import tempfile
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    shutil.copy(FIXTURES / "calibration.db", tmp.name)
    conn = sqlite3.connect(tmp.name)
    yield conn
    conn.close()
    Path(tmp.name).unlink()


def _read(filename):
    with open(FIXTURES / filename, "rb") as f:
        return f.read().decode("ascii")


def test_resnom_set1_matches_real_file_exactly(real_conn):
    assert generate_resnom(real_conn, "Set 1") == _read("RESNOM.txt")


def test_resvalue_matches_real_file_exactly(real_conn):
    assert generate_resvalue(real_conn, "Set 1") == _read("RESVALUE.TXT")


def test_highres_matches_real_file_exactly(real_conn):
    assert generate_highres(real_conn, "Set 1") == _read("HIGHRES.txt")


def test_onemeg_matches_real_file_exactly(real_conn):
    assert generate_onemeg(real_conn, "Set 1") == _read("ONEMEG.txt")


def test_station_file_set1_with_pn010034_matches_real_file_exactly(real_conn):
    filename, content = generate_station_file(real_conn, "Set 1", "PN010034")
    assert filename == "286300.txt"
    assert content == _read("286300.txt")


def test_zero_point_one_resistor_choice_is_independent_of_set(real_conn):
    """This is the whole point of the corrected workflow: Set 2 paired
    with PN010069 (not EQ358990) as the 0.1 Ohm choice must still work
    and write to 286325.txt (Set 2's station file), using PN010069's
    value - not forced to EQ358990 just because Set 2 was picked."""
    filename, content = generate_station_file(real_conn, "Set 2", "PN010069")
    assert filename == "286325.txt"
    assert "PN010069" not in content  # 286325's template has no comment tag on this line - value-only
    # cross-check against a direct DB lookup rather than a hardcoded literal
    from htbasic_export import get_latest_value
    expected = get_latest_value(real_conn, "PN010069")
    assert format_like(".1", expected) in content or str(round(expected, 9)).lstrip("0") in content


def test_untracked_resvalue_records_are_never_touched(real_conn):
    """RESVALUE contains resistors we don't manage at all (e.g. Rx 30269,
    40031...) - these must survive byte-for-byte regardless of what's in
    the database, since we have no data to update them with anyway."""
    result = generate_resvalue(real_conn, "Set 1")
    original = _read("RESVALUE.TXT")
    result_lines = result.split("\r\n")
    original_lines = original.split("\r\n")
    untracked_indices = [20, 23, 26, 29, 32, 35, 38, 44, 47, 50, 53, 56, 61]
    for i in untracked_indices:
        assert result_lines[i] == original_lines[i], f"untracked line {i} was modified"


def test_untracked_highres_records_are_never_touched(real_conn):
    result = generate_highres(real_conn, "Set 1").split("\r\n")
    original = _read("HIGHRES.txt").split("\r\n")
    for i in [3, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25]:
        assert result[i] == original[i], f"untracked line {i} was modified"


def test_set2_selection_uses_set2_resistors_and_relabels_comment_tags():
    """Caught during development: when the Set selection changes which
    physical resistor occupies a RESNOM slot, the '! PNxxxxx' comment tag
    must update too, or the file would mislabel a different resistor's
    value as belonging to the old one."""
    conn = connect(":memory:")
    mapping = [
        ("PN010022", 1.0, 1.00001255), ("PN010001", 1.0, 1.0000179),
        ("PN010014", 1e7, 1.0000134e7), ("PN010015", 1e7, 1.0000148e7),
        ("PN010017", 1e8, 1.000007e8), ("PN010016", 1e8, 1.000027e8),
        ("PN010050", 1e9, 0.999916e9), ("PN010048", 1e9, 0.999927e9),
    ]
    for pn, nominal, value in mapping:
        aid = upsert_asset(conn, serial=pn, model="M", asset_number=pn, nominal_ohms=nominal)
        insert_calibration(conn, aid, "2026-01-01", value, 5e-7, source="pdf_import")
    conn.commit()

    result_set2 = generate_resnom(conn, "Set 2")
    assert "! PN010001" in result_set2
    assert "! PN010022" not in result_set2
    assert "! PN010016" in result_set2
    assert "! PN010048" in result_set2
    assert "! PN010014" in result_set2  # both 10M standards always present
    assert "! PN010015" in result_set2


def test_generate_all_files_returns_all_six(real_conn):
    files = generate_all_files(real_conn, "Set 1", "PN010034")
    assert set(files.keys()) == {"RESNOM.txt", "RESVALUE.TXT", "HIGHRES.txt", "ONEMEG.txt", "286300.txt"}


def test_validate_required_resistors_passes_on_real_database(real_conn):
    assert validate_required_resistors(real_conn, "Set 1", "PN010034") == []
    assert validate_required_resistors(real_conn, "Set 2", "EQ358990") == []
    assert validate_required_resistors(real_conn, "Set 2", "PN010069") == []


def test_validate_required_resistors_catches_missing_asset():
    conn = connect(":memory:")
    result = validate_required_resistors(conn, "Set 1", "PN010034")
    assert len(result) > 0
    assert all(p["issue"] == "not in database" for p in result)


def test_format_like_preserves_scientific_notation_style():
    assert format_like("1.0000134E+7", 1.0000134e7) == "1.0000134E+7"


def test_format_like_preserves_no_leading_zero_convention():
    assert format_like(".100000761", 0.099999) == ".099999000"
