"""
db.py - thin SQLite helper for the calibration trending database.

Usage:
    from db import connect, upsert_asset, insert_calibration

    conn = connect("calibration.db")   # creates + applies schema.sql if needed
    asset_id = upsert_asset(conn, serial="73137", model="9334A-0.1",
                             asset_number="PN010069", nominal_ohms=0.1,
                             source_workbook="0_1_Ohm_master.xlsx", source_sheet="0.1 Ohm")
    insert_calibration(conn, asset_id, cal_date="2026-07-22",
                        measured_value=0.100000947, mu_relative=1.2e-7,
                        source="pdf_import", cert_number="WO-01467782",
                        cert_pdf_path="certs/WO-01467782.pdf")
    conn.commit()
"""

import sqlite3
from pathlib import Path

SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA_PATH.read_text())
    _migrate(conn)
    return conn


def _migrate(conn: sqlite3.Connection):
    """Adds columns introduced after a database was first created.
    CREATE TABLE IF NOT EXISTS (in schema.sql) only helps for brand-new
    databases - an existing calibrations/assets table needs these ALTER
    TABLEs to pick up new columns without losing any data already in it."""
    existing_cal_cols = {row[1] for row in conn.execute("PRAGMA table_info(calibrations)")}
    if "reviewer_comment" not in existing_cal_cols:
        conn.execute("ALTER TABLE calibrations ADD COLUMN reviewer_comment TEXT")
    if "excluded_from_regression" not in existing_cal_cols:
        conn.execute("ALTER TABLE calibrations ADD COLUMN excluded_from_regression INTEGER NOT NULL DEFAULT 0")
    if "reviewer_attachment_path" not in existing_cal_cols:
        conn.execute("ALTER TABLE calibrations ADD COLUMN reviewer_attachment_path TEXT")

    existing_asset_cols = {row[1] for row in conn.execute("PRAGMA table_info(assets)")}
    if "set_id" not in existing_asset_cols:
        conn.execute("ALTER TABLE assets ADD COLUMN set_id TEXT")
    conn.commit()


def upsert_asset(conn, serial: str, model: str, asset_number: str, nominal_ohms: float,
                  source_workbook: str = None, source_sheet: str = None) -> int:
    row = conn.execute("SELECT id, model, asset_number FROM assets WHERE serial = ?", (serial,)).fetchone()
    if row:
        asset_id, existing_model, existing_asset_number = row
        # Backfill any fields that were NULL before but we now have real values
        # for (e.g. this asset was first seen via cal_cert_importer.py --db,
        # which doesn't know the model/PN, and only later properly migrated
        # from Excel, which does).
        updates, params = [], []
        if existing_model is None and model is not None:
            updates.append("model = ?"); params.append(model)
        if existing_asset_number is None and asset_number is not None:
            updates.append("asset_number = ?"); params.append(asset_number)
        if updates:
            params.append(asset_id)
            conn.execute(f"UPDATE assets SET {', '.join(updates)} WHERE id = ?", params)
        return asset_id
    cur = conn.execute(
        "INSERT INTO assets (serial, model, asset_number, nominal_ohms, source_workbook, source_sheet) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (serial, model, asset_number, nominal_ohms, source_workbook, source_sheet),
    )
    return cur.lastrowid


def insert_calibration(conn, asset_id: int, cal_date: str, measured_value: float, mu_relative: float,
                        source: str, cert_number: str = None, cert_pdf_path: str = None) -> bool:
    """Returns True if a new row was inserted, False if it already existed (same asset+date)."""
    try:
        conn.execute(
            "INSERT INTO calibrations (asset_id, cert_number, cal_date, measured_value, mu_relative, "
            "source, cert_pdf_path) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (asset_id, cert_number, cal_date, measured_value, mu_relative, source, cert_pdf_path),
        )
        return True
    except sqlite3.IntegrityError:
        return False  # UNIQUE(asset_id, cal_date) hit - already imported, not an error


def update_asset(conn, asset_id: int, serial: str, model: str, asset_number: str, nominal_ohms: float,
                  set_id: str = None) -> tuple:
    """Returns (ok, error_message). error_message is set if the new serial
    collides with a different existing asset."""
    clash = conn.execute("SELECT id FROM assets WHERE serial = ? AND id != ?", (serial, asset_id)).fetchone()
    if clash:
        return False, f"Serial {serial} is already used by another asset (id {clash[0]})."
    conn.execute(
        "UPDATE assets SET serial = ?, model = ?, asset_number = ?, nominal_ohms = ?, set_id = ? WHERE id = ?",
        (serial, model, asset_number, nominal_ohms, set_id, asset_id),
    )
    return True, None


def bulk_assign_sets(conn, serial_to_set: dict) -> dict:
    """Applies a {serial: set_id} mapping directly - for loading a known
    serial->Set assignment in one go rather than editing each asset by
    hand. Returns {'updated': [...serials...], 'not_found': [...serials...]}
    so you can see exactly what happened, including any serial that didn't
    match an existing asset (typo, or not migrated yet)."""
    updated, not_found = [], []
    for serial, set_id in serial_to_set.items():
        cur = conn.execute("UPDATE assets SET set_id = ? WHERE serial = ?", (set_id, str(serial)))
        (updated if cur.rowcount > 0 else not_found).append(serial)
    conn.commit()
    return {"updated": updated, "not_found": not_found}


def delete_asset(conn, asset_id: int):
    """Deletes the asset and ALL of its calibration rows. Certificate PDF
    files on disk are left alone (not deleted) - only the database rows go."""
    conn.execute("DELETE FROM calibrations WHERE asset_id = ?", (asset_id,))
    conn.execute("DELETE FROM assets WHERE id = ?", (asset_id,))


def get_calibration(conn, calibration_id: int):
    row = conn.execute(
        "SELECT id, asset_id, cal_date, measured_value, mu_relative, cert_number, cert_pdf_path, "
        "reviewer_comment, excluded_from_regression, reviewer_attachment_path "
        "FROM calibrations WHERE id = ?", (calibration_id,),
    ).fetchone()
    if row is None:
        return None
    return {
        "id": row[0], "asset_id": row[1], "cal_date": row[2], "measured_value": row[3],
        "mu_relative": row[4], "cert_number": row[5], "cert_pdf_path": row[6],
        "reviewer_comment": row[7], "excluded_from_regression": bool(row[8]),
        "reviewer_attachment_path": row[9],
    }


def update_calibration(conn, calibration_id: int, cal_date: str, measured_value: float, mu_relative: float,
                        reviewer_comment: str = None, excluded_from_regression: bool = False,
                        reviewer_attachment_path: str = None, keep_existing_attachment: bool = False) -> tuple:
    """Returns (ok, error_message). error_message is set if the new date
    collides with another existing calibration for the same asset.
    If keep_existing_attachment is True, reviewer_attachment_path is left
    untouched (caller didn't upload a new one) rather than being cleared."""
    row = conn.execute("SELECT asset_id FROM calibrations WHERE id = ?", (calibration_id,)).fetchone()
    if row is None:
        return False, "Calibration not found."
    asset_id = row[0]
    clash = conn.execute(
        "SELECT id FROM calibrations WHERE asset_id = ? AND cal_date = ? AND id != ?",
        (asset_id, cal_date, calibration_id),
    ).fetchone()
    if clash:
        return False, f"This asset already has a calibration dated {cal_date}."

    if keep_existing_attachment:
        conn.execute(
            "UPDATE calibrations SET cal_date = ?, measured_value = ?, mu_relative = ?, "
            "reviewer_comment = ?, excluded_from_regression = ? WHERE id = ?",
            (cal_date, measured_value, mu_relative, reviewer_comment, int(excluded_from_regression), calibration_id),
        )
    else:
        conn.execute(
            "UPDATE calibrations SET cal_date = ?, measured_value = ?, mu_relative = ?, "
            "reviewer_comment = ?, excluded_from_regression = ?, reviewer_attachment_path = ? WHERE id = ?",
            (cal_date, measured_value, mu_relative, reviewer_comment, int(excluded_from_regression),
             reviewer_attachment_path, calibration_id),
        )
    return True, None


def delete_calibration(conn, calibration_id: int):
    """Deletes the calibration row. The certificate PDF file on disk (if
    any) is left alone - only the database row goes."""
    conn.execute("DELETE FROM calibrations WHERE id = ?", (calibration_id,))
