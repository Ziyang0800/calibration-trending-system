"""
htbasic_export.py

Generates the legacy HTBasic 3458A calibration program standard files
(RESNOM, RESVALUE, HIGHRES, ONEMEG, 286300, 286325) from calibration.db.

WORKFLOW (confirmed in chat): there are only two real user choices, not
three:
  1. Set 1/Station B-1  OR  Set 2/Station B-2 - a single paired choice.
     It governs both which resistors are used for the 1 Ohm-1 GOhm
     records (RESNOM/RESVALUE/HIGHRES/ONEMEG) AND which station file
     gets generated (286300 for Set 1/B-1, 286325 for Set 2/B-2).
  2. Which physical 0.1 Ohm resistor (PN010034 / EQ358990 / PN010069)
     goes into that station file - a genuinely separate, independent
     choice, NOT tied to the Set/Station pick above. This is why an
     earlier version of 286325.txt was found to contain PN010069's value
     even though EQ358990 is "Set 2's" 0.1 Ohm resistor - that's not a
     bug, a station's 0.1 Ohm resistor can be any of the three.
"""

# --- resistor mapping (verified against the real database - see chat) ---

SET_STATION_MAPPING = {
    "Set 1": {  # pairs with Station B-1 / 286300.txt
        "1": "PN010022", "10": "PN010002", "100": "PN010004",
        "1000": "PN010006", "10000": "PN010008", "100000": "PN010010", "1000000": "PN010012",
        "10000000": "PN010014", "100000000": "PN010017", "1000000000": "PN010050",
        "station": "Station B-1", "station_file": "286300.txt",
    },
    "Set 2": {  # pairs with Station B-2 / 286325.txt
        "1": "PN010001", "10": "PN010003", "100": "PN010005",
        "1000": "PN010007", "10000": "PN010009", "100000": "PN010011", "1000000": "PN010013",
        "10000000": "PN010015", "100000000": "PN010016", "1000000000": "PN010048",
        "station": "Station B-2", "station_file": "286325.txt",
    },
}

# the three 0.1 Ohm resistors available for the station-file choice, independent of Set
ZERO_POINT_ONE_OHM_OPTIONS = {
    "PN010034": "PN010034 (Set 1's 0.1 Ohm)",
    "EQ358990": "EQ358990 (Set 2's 0.1 Ohm)",
    "PN010069": "PN010069 (Set 3's 0.1 Ohm)",
}

# which resistors each legacy file needs, given the Set/Station choice
# (and, for the station file, the separately-chosen 0.1 Ohm resistor)
REQUIRED_FOR_FILE = {
    "RESNOM": lambda set_name, zero_pt_one_pn: [
        SET_STATION_MAPPING[set_name]["1"],
        SET_STATION_MAPPING["Set 1"]["10000000"], SET_STATION_MAPPING["Set 2"]["10000000"],
        SET_STATION_MAPPING[set_name]["100000000"],
        SET_STATION_MAPPING[set_name]["1000000000"],
    ],
    "RESVALUE": lambda set_name, zero_pt_one_pn: [
        SET_STATION_MAPPING["Set 1"]["10"], SET_STATION_MAPPING["Set 2"]["10"],
        SET_STATION_MAPPING["Set 1"]["100"], SET_STATION_MAPPING["Set 2"]["100"],
        SET_STATION_MAPPING["Set 1"]["1000"], SET_STATION_MAPPING["Set 2"]["1000"],
        SET_STATION_MAPPING["Set 1"]["10000"], SET_STATION_MAPPING["Set 2"]["10000"],
    ],
    "HIGHRES": lambda set_name, zero_pt_one_pn: [
        SET_STATION_MAPPING["Set 1"]["100000"], SET_STATION_MAPPING["Set 2"]["100000"],
    ],
    "ONEMEG": lambda set_name, zero_pt_one_pn: [
        SET_STATION_MAPPING["Set 1"]["1000000"], SET_STATION_MAPPING["Set 2"]["1000000"],
    ],
    "station_file": lambda set_name, zero_pt_one_pn: [zero_pt_one_pn],
}


def get_latest_value(conn, asset_number: str):
    """Raw measured value from the most recent calibration for the asset
    with this PN/EQ number - not a regression prediction (confirmed).
    Returns None if the asset doesn't exist or has no calibrations."""
    row = conn.execute(
        "SELECT c.measured_value FROM calibrations c "
        "JOIN assets a ON a.id = c.asset_id "
        "WHERE a.asset_number = ? "
        "ORDER BY c.cal_date DESC LIMIT 1",
        (asset_number,),
    ).fetchone()
    return row[0] if row else None


def validate_required_resistors(conn, set_name: str, zero_pt_one_pn: str) -> list:
    """
    Checks every resistor needed to generate ALL 6 files for this Set
    (which also determines the station file) plus the separately-chosen
    0.1 Ohm resistor. Returns a list of problem dicts - empty means
    generation can proceed. Each has 'nominal', 'asset_number', and
    'issue' ('not in database' or 'no calibration history'), matching the
    spec's validation requirement (no partial files).
    """
    problems = []
    seen = set()

    for file_name, resolver in REQUIRED_FOR_FILE.items():
        for asset_number in resolver(set_name, zero_pt_one_pn):
            if asset_number in seen:
                continue
            seen.add(asset_number)

            row = conn.execute(
                "SELECT nominal_ohms FROM assets WHERE asset_number = ?", (asset_number,)
            ).fetchone()
            if row is None:
                problems.append({"nominal": "?", "asset_number": asset_number, "issue": "not in database"})
                continue

            value = get_latest_value(conn, asset_number)
            if value is None:
                problems.append({"nominal": row[0], "asset_number": asset_number, "issue": "no calibration history"})

    return problems


import os

from htbasic_format import format_like

TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "htbasic_templates")


def _read_template_lines(filename: str) -> list:
    path = os.path.join(TEMPLATE_DIR, filename)
    with open(path, "rb") as f:
        text = f.read().decode("ascii")
    return text.split("\r\n")


def _patch_value_line(line: str, pn: str, conn) -> str:
    """Replaces the numeric value AND, if the template line already tags
    a resistor via '! PNxxxxx', updates that tag to match pn too - this
    matters when a Set selection changes which physical resistor occupies
    a slot (e.g. RESNOM's ONE/100M/1G lines), so the comment doesn't end
    up mislabeling a different resistor's value. Leading whitespace and
    the field width up to the comment are preserved so alignment/columns
    stay identical either way."""
    new_value = get_latest_value(conn, pn)
    if new_value is None:
        raise ValueError(f"No calibration value available for {pn}")

    leading_ws = line[: len(line) - len(line.lstrip())]
    rest = line.lstrip()

    if "!" in rest:
        num_field, _old_comment = rest.split("!", 1)
        comment_part = f"! {pn}"
        field_width = len(num_field)
        new_num = format_like(num_field.strip(), new_value)
        return f"{leading_ws}{new_num.ljust(field_width)}{comment_part}"
    else:
        new_num = format_like(rest.strip(), new_value)
        return f"{leading_ws}{new_num}"


def generate_resnom(conn, set_name: str) -> str:
    """Lines (0-indexed): 1=ONE, 3=10M#1(always PN010014), 5=100M, 7=1G, 9=10M#2(always PN010015)."""
    lines = _read_template_lines("RESNOM.txt")
    one_pn = SET_STATION_MAPPING[set_name]["1"]
    hundred_m_pn = SET_STATION_MAPPING[set_name]["100000000"]
    one_g_pn = SET_STATION_MAPPING[set_name]["1000000000"]

    lines[1] = _patch_value_line(lines[1], one_pn, conn)
    lines[3] = _patch_value_line(lines[3], SET_STATION_MAPPING["Set 1"]["10000000"], conn)
    lines[5] = _patch_value_line(lines[5], hundred_m_pn, conn)
    lines[7] = _patch_value_line(lines[7], one_g_pn, conn)
    lines[9] = _patch_value_line(lines[9], SET_STATION_MAPPING["Set 2"]["10000000"], conn)
    return "\r\n".join(lines)


def generate_resvalue(conn, set_name: str) -> str:
    """RESVALUE contains records for OTHER resistors we don't track at all -
    those lines are left completely untouched. Only these 8 known Rx-Serial#
    lines (per the spec) get their value refreshed. Not actually Set-
    dependent (both Sets' 10/100/1k/10k resistors are always all present),
    but kept as a parameter for a consistent call signature."""
    lines = _read_template_lines("RESVALUE.TXT")
    patch_map = {
        2: "PN010002", 5: "PN010003",     # Rx 10001, 10010
        8: "PN010005", 11: "PN010004",    # Rx 20014, 20050
        14: "PN010007", 17: "PN010006",   # Rx 30162, 30267
        41: "PN010009", 59: "PN010008",   # Rx 40059, 40233
    }
    for idx, pn in patch_map.items():
        lines[idx] = _patch_value_line(lines[idx], pn, conn)
    return "\r\n".join(lines)


def generate_highres(conn, set_name: str) -> str:
    """Only S/N366 (PN010011) and S/N50031 (PN010010) get refreshed; every
    other S/N record in the file is untracked and left untouched."""
    lines = _read_template_lines("HIGHRES.txt")
    patch_map = {1: "PN010011", 5: "PN010010"}  # value line following S/N366, S/N50031
    for idx, pn in patch_map.items():
        lines[idx] = _patch_value_line(lines[idx], pn, conn)
    return "\r\n".join(lines)


def generate_onemeg(conn, set_name: str) -> str:
    """Both records (S/N132 -> PN010012, S/N133 -> PN010013) are tracked."""
    lines = _read_template_lines("ONEMEG.txt")
    lines[1] = _patch_value_line(lines[1], "PN010012", conn)
    lines[3] = _patch_value_line(lines[3], "PN010013", conn)
    return "\r\n".join(lines)


def generate_station_file(conn, set_name: str, zero_pt_one_pn: str) -> tuple:
    """Returns (filename, content). Which FILE gets written (286300 vs
    286325) is fixed by set_name (Set 1 -> 286300, Set 2 -> 286325) - but
    WHICH 0.1 Ohm resistor's value goes into it is the separate,
    independently-chosen zero_pt_one_pn (any of the three), confirmed in
    chat - it is NOT tied to set_name."""
    filename = SET_STATION_MAPPING[set_name]["station_file"]
    lines = _read_template_lines(filename)
    lines[0] = _patch_value_line(lines[0], zero_pt_one_pn, conn)
    return filename, "\r\n".join(lines)


def generate_all_files(conn, set_name: str, zero_pt_one_pn: str) -> dict:
    """Generates all 6 files for this Set/0.1-Ohm-resistor combination.
    Returns {filename: content}. Caller should run
    validate_required_resistors() first and not call this if it returned
    any problems (no partial files, per the spec)."""
    station_filename, station_content = generate_station_file(conn, set_name, zero_pt_one_pn)
    return {
        "RESNOM.txt": generate_resnom(conn, set_name),
        "RESVALUE.TXT": generate_resvalue(conn, set_name),
        "HIGHRES.txt": generate_highres(conn, set_name),
        "ONEMEG.txt": generate_onemeg(conn, set_name),
        station_filename: station_content,
    }
