"""
test_trending.py - Phase 3 validation.

The historical data below is PN010069's real calibration history (10 real
points from 0_1_Ohm_master.xlsx). The key thing this validates: the
regression fit is computed on all points EXCEPT the newest one, but
Prediction/Lower/Upper are still reported for every row (the newest
included) - see the module docstring in trending.py for why. This test
proves an exact match to Excel's real cached H/I/J values across ALL 10
rows, including the newest one (which is evaluated from, but excluded
from, the fit).
"""

from datetime import date, timedelta

import pytest

from trending import compute_trend, predict_at

NOMINAL = 0.1

# (date, measured_value) - PN010069's real history, oldest to newest
HISTORY = [
    (date(2020, 5, 20), 0.100000334),
    (date(2021, 5, 6), 0.100000403),
    (date(2021, 12, 20), 0.100000393),
    (date(2022, 7, 28), 0.10000064),
    (date(2023, 2, 11), 0.100000451),
    (date(2023, 10, 9), 0.100000653),
    (date(2024, 8, 16), 0.100000554),
    (date(2025, 3, 10), 0.100000639),
    (date(2025, 12, 17), 0.100000761),
    (date(2026, 7, 22), 0.100000947),   # newest - excluded from the fit, still evaluated
]

# Excel's real cached H/I/J for ALL 10 rows above, read straight from the
# recalculated workbook - including row 12 (the newest), which Excel
# computes from the fit over the OTHER 9 rows.
EXCEL_PREDICTED = [
    0.100000343885924, 0.100000409265585, 0.100000451734425, 0.10000049271313,
    0.100000529593964, 0.100000574298006, 0.10000063241326, 0.100000670784229,
    0.100000723311478, 0.100000763731382,
]
EXCEL_LOWER = [
    0.100000116074223, 0.100000195322938, 0.10000024404694, 0.10000028877322,
    0.100000326998951, 0.10000037070296, 0.100000423295375, 0.100000455562672,
    0.100000496893152, 0.100000526726113,
]
EXCEL_UPPER = [
    0.100000571697626, 0.100000623208232, 0.10000065942191, 0.100000696653039,
    0.100000732188977, 0.100000777893051, 0.100000841531145, 0.100000886005786,
    0.100000949729804, 0.100001000736652,
]


def test_matches_excel_exactly_across_all_rows_including_newest():
    dates = [d for d, _ in HISTORY]
    measured = [m for _, m in HISTORY]
    rows, stats = compute_trend(dates, measured, nominal=NOMINAL)

    assert stats["n"] == 9          # fit uses all-but-the-newest
    assert len(rows) == 10          # but every row (newest included) gets a result
    assert rows[-1]["in_fit"] is False
    assert all(r["in_fit"] for r in rows[:-1])

    for i, r in enumerate(rows):
        assert r["predicted"] == pytest.approx(EXCEL_PREDICTED[i], abs=1e-9)
        assert r["lower"] == pytest.approx(EXCEL_LOWER[i], abs=1e-9)
        assert r["upper"] == pytest.approx(EXCEL_UPPER[i], abs=1e-9)


def test_newest_point_falls_within_or_outside_prediction_interval():
    """This is the actual point of excluding the newest from the fit: you
    can check whether it landed inside the expected range."""
    dates = [d for d, _ in HISTORY]
    measured = [m for _, m in HISTORY]
    rows, _ = compute_trend(dates, measured, nominal=NOMINAL)

    newest = rows[-1]
    within_interval = newest["lower"] <= newest["measured_value"] <= newest["upper"]
    # PN010069's real newest point (0.100000947) is within its predicted
    # range (0.100000527 - 0.100001001) - no anomaly for this asset
    assert within_interval


def test_predict_at_future_date():
    """predict_at should extrapolate beyond the last historical point."""
    dates = [d for d, _ in HISTORY]
    measured = [m for _, m in HISTORY]
    rows, stats = compute_trend(dates, measured, nominal=NOMINAL)

    last_accum_days = (dates[-1] - dates[0]).days
    future_days = last_accum_days + 180  # ~6 months past the last cal
    fitted, lower, upper = predict_at(future_days, stats)

    assert lower < fitted < upper
    assert fitted > rows[-1]["predicted"]  # further out on a clear upward trend


def test_raises_on_too_few_points():
    with pytest.raises(ValueError):
        compute_trend(
            [date(2024, 1, 1), date(2024, 6, 1), date(2024, 9, 1)],
            [0.1, 0.1000001, 0.1000002],
            nominal=0.1,
        )


def test_no_warning_on_perfect_fit():
    """Perfect-fit (zero residual variance) data shouldn't raise any
    divide-by-zero warnings."""
    import warnings
    from datetime import timedelta

    d0 = date(2020, 1, 1)
    dates = [d0 + timedelta(days=x) for x in [0, 100, 200, 300, 400, 500]]
    measured = [1.0 + 1e-6 * x for x in [0, 100, 200, 300, 400, 500]]

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        compute_trend(dates, measured, nominal=1.0)


def test_excluding_an_outlier_removes_it_from_the_fit():
    """A manually-excluded point should still get a row (still shown,
    still evaluated against the fit) but should NOT influence slope/
    intercept/Syx/etc. Proof: tampering that point's value while it's
    excluded should have ZERO effect on the fit stats, since the fit
    never looks at it - only on that one row's own displayed values."""
    dates = [d for d, _ in HISTORY]
    measured = [m for _, m in HISTORY]
    excluded = [False] * len(dates)
    excluded[3] = True

    rows_a, stats_a = compute_trend(dates, measured, nominal=NOMINAL, excluded=excluded)

    tampered = list(measured)
    tampered[3] = tampered[3] + 0.01  # huge, arbitrary corruption of the excluded point
    rows_b, stats_b = compute_trend(dates, tampered, nominal=NOMINAL, excluded=excluded)

    # fit stats identical - the excluded point's value never entered the fit
    for key in ("n", "df", "slope", "intercept", "xbar", "Syx", "SSx"):
        assert stats_a[key] == pytest.approx(stats_b[key], rel=1e-12), key

    # but that row's own displayed measured_value differs, and now reads as an outlier
    assert rows_a[3]["in_fit"] is False
    assert rows_a[3]["manually_excluded"] is True
    assert rows_b[3]["measured_value"] == pytest.approx(measured[3] + 0.01)
    assert rows_b[3]["out_of_trend"] is True  # the injected outlier is clearly outside its own PI

    # every other row's in_fit is unaffected
    for i, r in enumerate(rows_a):
        if i not in (3, len(rows_a) - 1):
            assert r["in_fit"] is True
            assert r["manually_excluded"] is False


def test_out_of_trend_is_computed_for_every_row_not_just_newest():
    dates = [d for d, _ in HISTORY]
    measured = [m for _, m in HISTORY]
    rows, _ = compute_trend(dates, measured, nominal=NOMINAL)
    # every row should carry the flag, regardless of fit membership
    assert all("out_of_trend" in r for r in rows)

