"""
trending.py - Phase 3.

Replicates, in Python, exactly what the Excel workbook's formulas compute:

    Since Last Cal [Days]  B_n = A_n - A_(n-1)                    (0 for first row)
    Accumulated [Days]     C_n = SUM(B_3:B_n)                     (running total)
    Error [PPM]            D_n = (measured_n - nominal) / nominal * 1e6
    Drifted [PPM]          E_n = D_n - D_(n-1)                    (None for first row)
    Prediction             H_n = FORECAST.LINEAR(C_n, y_fit, x_fit)
    Lower / Upper          H_n -+ |T.INV(0.025, df)| * Syx * sqrt(1 + 1/n_fit + (C_n - xbar)^2 / SSx)

IMPORTANT and easy to misread at first (I did): the regression fit itself
(slope, intercept, n, df, xbar, Syx, SSx) is deliberately computed EXCLUDING
the most recent calibration. This is intentional, not a bug - it means the
newest point's Prediction/Lower/Upper represent what prior trend would have
expected for it, so you can check whether the actual new measurement falls
inside that expected range (a drift/anomaly check). Every row's
Prediction/Lower/Upper - historical rows too - are evaluated from that same
fixed fit, just plugged in at that row's own x.

On top of that, a calibration can also be manually marked excluded_from_fit
(a reviewer-verified outlier) via the `excluded` argument - those points are
ALSO left out of the fit (in addition to the newest), but still get a
row in the output (still evaluated against the fit, still shown in the UI)
so nothing is silently erased - only its influence on the trend line is
removed. Each row reports:
  - in_fit: whether this point actually contributed to the regression
    (False for the newest point, and False for any manually excluded one)
  - out_of_trend: whether this point's own measured value falls outside
    its own predicted 95% interval (computed for every row, not just the
    newest - an in-fit historical point can still be flagged, e.g. a
    high-leverage outlier)

Verified against the real workbook's cached values for PN010069, including
the newest row's H/I/J (see tests/test_trending.py) - matches to float
precision.

Usage:
    from trending import compute_trend, predict_at

    rows, stats = compute_trend(dates, measured_values, nominal=0.1)
    # or, to exclude a verified-outlier point (say index 3) from the fit:
    rows, stats = compute_trend(dates, measured_values, nominal=0.1,
                                 excluded=[False, False, False, True, False, ...])
"""

from datetime import date

import numpy as np
from scipy import stats as scipy_stats


def compute_trend(dates: list, measured_values: list, nominal: float, excluded: list = None) -> tuple:
    """
    dates: list of datetime.date (or datetime), ascending, one per calibration
    measured_values: matching list of measured values (ohms)
    nominal: nominal value of the asset (ohms)
    excluded: optional list of bool, same length as dates - True marks a
        point as a verified outlier to leave OUT of the regression fit
        (on top of the newest point, which is always excluded regardless).
        Defaults to all False.

    Returns (rows, stats) with one row per INPUT point (all of them,
    including the newest and any excluded ones), each evaluated from the
    fit over whatever points remain after exclusions.
    """
    n_total = len(dates)
    if excluded is None:
        excluded = [False] * n_total
    if len(excluded) != n_total:
        raise ValueError("excluded must be the same length as dates.")
    if list(dates) != sorted(dates):
        raise ValueError("dates must be sorted ascending - sort before calling this.")

    # the newest point is always held out of the fit, regardless of `excluded`
    fit_mask = np.array([not excluded[i] for i in range(n_total)], dtype=bool)
    fit_mask[-1] = False

    n = int(fit_mask.sum())
    if n < 3:
        raise ValueError(
            f"Need at least 3 points remaining for the regression fit after "
            f"excluding the newest calibration and any manually-excluded "
            f"outliers (got {n}, from {n_total} total points, "
            f"{sum(excluded)} manually excluded)."
        )

    d0 = dates[0]
    accumulated_days = [(d - d0).days for d in dates]
    x_all = np.array(accumulated_days, dtype=float)
    y_all = np.array(measured_values, dtype=float)

    x_fit = x_all[fit_mask]
    y_fit = y_all[fit_mask]

    xbar = x_fit.mean()
    ybar = y_fit.mean()
    SSx = np.sum((x_fit - xbar) ** 2)          # Excel: DEVSQ(x_fit)
    Sxy = np.sum((x_fit - xbar) * (y_fit - ybar))

    slope = Sxy / SSx
    intercept = ybar - slope * xbar

    fitted_fit = intercept + slope * x_fit
    residuals = y_fit - fitted_fit
    df = n - 2
    Syx = float(np.sqrt(np.sum(residuals ** 2) / df))   # Excel: STEYX(y_fit, x_fit)

    t_crit = float(scipy_stats.t.ppf(0.975, df))         # Excel: ABS(T.INV(0.025, df))

    # --- evaluate the fit at EVERY point, including excluded/newest ones ---
    fitted_all = intercept + slope * x_all
    margin_all = t_crit * Syx * np.sqrt(1 + 1 / n + (x_all - xbar) ** 2 / SSx)
    lower_all = fitted_all - margin_all
    upper_all = fitted_all + margin_all

    error_ppm = (y_all - nominal) / nominal * 1e6
    drift_ppm = np.diff(error_ppm, prepend=np.nan)

    rows = []
    for i in range(n_total):
        rows.append({
            "date": dates[i],
            "accumulated_days": accumulated_days[i],
            "measured_value": float(y_all[i]),
            "error_ppm": float(error_ppm[i]),
            "drift_ppm": None if i == 0 else float(drift_ppm[i]),
            "predicted": float(fitted_all[i]),
            "lower": float(lower_all[i]),
            "upper": float(upper_all[i]),
            "in_fit": bool(fit_mask[i]),
            "out_of_trend": not (lower_all[i] <= y_all[i] <= upper_all[i]),
            "manually_excluded": bool(excluded[i]),
        })

    stats = {
        "n": n, "df": df, "slope": float(slope), "intercept": float(intercept),
        "xbar": float(xbar), "Syx": Syx, "SSx": float(SSx), "t_crit": t_crit,
        "first_date": d0, "nominal": nominal,
    }
    return rows, stats


def predict_at(accumulated_days: float, stats: dict) -> tuple:
    """Predict measured value (+ 95% PI) at a given accumulated-days x,
    e.g. for a future not-yet-measured calibration. Returns (fitted, lower, upper)."""
    slope, intercept = stats["slope"], stats["intercept"]
    n, df, xbar, Syx, SSx, t_crit = (stats[k] for k in ("n", "df", "xbar", "Syx", "SSx", "t_crit"))
    fitted = intercept + slope * accumulated_days
    margin = t_crit * Syx * ((1 + 1 / n + (accumulated_days - xbar) ** 2 / SSx) ** 0.5)
    return fitted, fitted - margin, fitted + margin


def compute_trend_for_asset(conn, asset_id: int) -> tuple:
    """Convenience wrapper: pulls calibration history for an asset straight
    from the Phase-2 database and runs compute_trend on it, respecting any
    manually-excluded (verified outlier) points."""
    nominal = conn.execute("SELECT nominal_ohms FROM assets WHERE id = ?", (asset_id,)).fetchone()
    if nominal is None:
        raise ValueError(f"No asset with id={asset_id}")
    nominal = nominal[0]

    rows = conn.execute(
        "SELECT cal_date, measured_value, excluded_from_regression FROM calibrations "
        "WHERE asset_id = ? ORDER BY cal_date",
        (asset_id,),
    ).fetchall()
    dates = [date.fromisoformat(r[0]) for r in rows]
    measured = [r[1] for r in rows]
    excluded = [bool(r[2]) for r in rows]
    return compute_trend(dates, measured, nominal, excluded=excluded)
