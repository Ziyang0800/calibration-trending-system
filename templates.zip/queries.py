"""
queries.py - data access layer for the dashboard (Phase 4) and Excel
export (Phase 5). Keeps SQL and trend-computation out of app.py/export
scripts so both can share the same logic.
"""

from datetime import date, datetime

from trending import compute_trend, predict_at
from stability_specs import assess_drift, get_spec_description

MIN_POINTS_FOR_TREND = 4  # matches trending.py's own minimum


def list_assets(conn):
    """One row per asset, with latest calibration + a simple trend status
    ('ok' / 'out_of_trend' / 'insufficient_data') for the dashboard list."""
    assets = conn.execute(
        "SELECT id, serial, model, asset_number, nominal_ohms, source_sheet, set_id FROM assets "
        "ORDER BY nominal_ohms, serial"
    ).fetchall()

    results = []
    for asset_id, serial, model, asset_number, nominal, source_sheet, set_id in assets:
        cals = conn.execute(
            "SELECT cal_date, measured_value, excluded_from_regression FROM calibrations "
            "WHERE asset_id = ? ORDER BY cal_date",
            (asset_id,),
        ).fetchall()

        entry = {
            "id": asset_id, "serial": serial, "model": model, "asset_number": asset_number,
            "nominal_ohms": nominal, "source_sheet": source_sheet, "set_id": set_id,
            "num_calibrations": len(cals),
            "last_cal_date": cals[-1][0] if cals else None,
            "last_measured": cals[-1][1] if cals else None,
            "status": "insufficient_data",
        }

        if len(cals) >= MIN_POINTS_FOR_TREND:
            dates = [date.fromisoformat(c[0]) for c in cals]
            measured = [c[1] for c in cals]
            excluded = [bool(c[2]) for c in cals]
            rows, _ = compute_trend(dates, measured, nominal, excluded=excluded)
            newest = rows[-1]
            entry["status"] = "out_of_trend" if newest["out_of_trend"] else "ok"

        results.append(entry)
    return results


def list_assets_grouped_by_set(conn):
    """Same data as list_assets, grouped into per-Set sections for the
    dashboard: [{'set_id': 'Set 1', 'assets': [...], 'total': N,
    'ok_count': N, 'out_count': N, 'insufficient_count': N}, ...].
    Assets with no Set assigned land in a final 'Unassigned' group rather
    than being silently dropped."""
    assets = list_assets(conn)

    groups = {}
    for a in assets:
        key = a["set_id"] or "Unassigned"
        groups.setdefault(key, []).append(a)

    def sort_key(name):
        return (1, name) if name == "Unassigned" else (0, name)

    result = []
    for set_name in sorted(groups.keys(), key=sort_key):
        group_assets = groups[set_name]
        result.append({
            "set_id": set_name,
            "assets": group_assets,
            "total": len(group_assets),
            "ok_count": sum(1 for a in group_assets if a["status"] == "ok"),
            "out_count": sum(1 for a in group_assets if a["status"] == "out_of_trend"),
            "insufficient_count": sum(1 for a in group_assets if a["status"] == "insufficient_data"),
        })
    return result


def get_asset_detail(conn, asset_id: int):
    """Full detail for one asset: identity, all calibrations (with cert
    paths, reviewer comments, and exclusion flags where set), trend/
    regression results if there's enough data, and a manufacturer
    stability-spec assessment of the two most recent calibrations
    (independent of the regression - see stability_specs.py)."""
    asset_row = conn.execute(
        "SELECT id, serial, model, asset_number, nominal_ohms, source_workbook, source_sheet, set_id "
        "FROM assets WHERE id = ?",
        (asset_id,),
    ).fetchone()
    if asset_row is None:
        return None

    asset = {
        "id": asset_row[0], "serial": asset_row[1], "model": asset_row[2],
        "asset_number": asset_row[3], "nominal_ohms": asset_row[4],
        "source_workbook": asset_row[5], "source_sheet": asset_row[6], "set_id": asset_row[7],
    }

    cal_rows = conn.execute(
        "SELECT id, cal_date, measured_value, mu_relative, source, cert_number, cert_pdf_path, "
        "reviewer_comment, excluded_from_regression, reviewer_attachment_path "
        "FROM calibrations WHERE asset_id = ? ORDER BY cal_date",
        (asset_id,),
    ).fetchall()

    calibrations = [{
        "id": r[0], "date": r[1], "measured_value": r[2], "mu_relative": r[3],
        "source": r[4], "cert_number": r[5], "cert_pdf_path": r[6],
        "reviewer_comment": r[7], "excluded_from_regression": bool(r[8]),
        "reviewer_attachment_path": r[9],
    } for r in cal_rows]

    trend = None
    if len(calibrations) >= MIN_POINTS_FOR_TREND:
        dates = [date.fromisoformat(c["date"]) for c in calibrations]
        measured = [c["measured_value"] for c in calibrations]
        excluded = [c["excluded_from_regression"] for c in calibrations]
        rows, stats = compute_trend(dates, measured, asset["nominal_ohms"], excluded=excluded)
        # merge trend numbers back into the calibration rows for display
        nominal = asset["nominal_ohms"]
        for cal, r in zip(calibrations, rows):
            cal.update({
                "accumulated_days": r["accumulated_days"], "error_ppm": r["error_ppm"],
                "drift_ppm": r["drift_ppm"], "predicted": r["predicted"],
                "lower": r["lower"], "upper": r["upper"], "in_fit": r["in_fit"],
                "out_of_trend": r["out_of_trend"],
                # ppm-equivalents of the regression outputs, for display
                # alongside the stability check (which is inherently ppm-based)
                "predicted_error_ppm": (r["predicted"] - nominal) / nominal * 1e6,
                "lower_error_ppm": (r["lower"] - nominal) / nominal * 1e6,
                "upper_error_ppm": (r["upper"] - nominal) / nominal * 1e6,
            })
        trend = stats
    else:
        # no regression yet, but error_ppm/drift_ppm are cheap and don't
        # need one - compute them directly so the stability check (which
        # only needs 2 points, not 4) still works, and the history table
        # still shows Error/Drift columns even for a brand-new asset.
        nominal = asset["nominal_ohms"]
        prev_error = None
        for cal in calibrations:
            error_ppm = (cal["measured_value"] - nominal) / nominal * 1e6
            cal["error_ppm"] = error_ppm
            cal["drift_ppm"] = None if prev_error is None else error_ppm - prev_error
            prev_error = error_ppm

    # --- manufacturer stability spec assessment (separate from the regression) ---
    stability = None
    if len(calibrations) >= 2:
        latest, previous = calibrations[-1], calibrations[-2]
        elapsed_days = (date.fromisoformat(latest["date"]) - date.fromisoformat(previous["date"])).days
        observed_drift_ppm = latest["error_ppm"] - previous["error_ppm"]
        result = assess_drift(asset["model"], observed_drift_ppm, elapsed_days)
        stability = {
            "previous_date": previous["date"], "previous_error_ppm": previous["error_ppm"],
            "latest_date": latest["date"], "latest_error_ppm": latest["error_ppm"],
            "observed_drift_ppm": observed_drift_ppm, "elapsed_days": elapsed_days,
            "allowance_ppm": result["allowance_ppm"], "exceeds": result["exceeds"],
            "spec_description": get_spec_description(asset["model"]),
        }

    return {"asset": asset, "calibrations": calibrations, "trend": trend, "stability": stability}
