"""
report_pdf.py - generates a single PDF report for a set of selected assets.

Layout (per your choices): compact per-asset block - identity, trend
chart, and latest-calibration summary only (not the full history table) -
with assets flowing continuously down the page rather than one-per-page,
using reportlab's flowable layout so it breaks pages naturally wherever
content runs out of room.

Usage:
    from report_pdf import generate_report
    path = generate_report(conn, asset_ids=[1, 3, 7], out_path="report.pdf")
"""

import io
from datetime import date, datetime
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use("Agg")  # no display/GUI backend needed - just rendering to PNG bytes
import matplotlib.pyplot as plt

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, HRFlowable,
)

from queries import get_asset_detail

STEEL = colors.HexColor("#2f5f7a")
WARN = colors.HexColor("#b4530f")
GREY = colors.HexColor("#9a9186")
INK_DIM = colors.HexColor("#5c6773")


def _status_of(cal: dict) -> tuple:
    """Returns (label, color) for the latest calibration's status."""
    if cal.get("excluded_from_regression"):
        return "excluded", GREY
    if cal.get("out_of_trend"):
        return "out of trend", WARN
    if "predicted" in cal:
        return "ok", STEEL
    return "insufficient history", GREY


def _render_chart_png(calibrations: list, asset: dict) -> bytes:
    fig, ax = plt.subplots(figsize=(6.2, 3.0), dpi=150)

    xs = [c["accumulated_days"] for c in calibrations]
    measured = [c["measured_value"] for c in calibrations]
    predicted = [c.get("predicted") for c in calibrations]
    lower = [c.get("lower") for c in calibrations]
    upper = [c.get("upper") for c in calibrations]

    if all(v is not None for v in lower + upper):
        ax.fill_between(xs, lower, upper, color="#2f5f7a", alpha=0.06, linewidth=0)
        ax.plot(xs, upper, color="#8aa4b3", linestyle="-", linewidth=1.0, label="Upper Bound")
        ax.plot(xs, lower, color="#8aa4b3", linestyle="-", linewidth=1.0, label="Lower Bound")
        ax.plot(xs, predicted, color="#5c6773", linestyle=":", linewidth=1.4, label="Prediction")

    point_colors = []
    for c in calibrations:
        if c.get("excluded_from_regression"):
            point_colors.append("#9a9186")
        elif c.get("out_of_trend"):
            point_colors.append("#b4530f")
        else:
            point_colors.append("#2f5f7a")
    ax.scatter(xs, measured, c=point_colors, s=22, zorder=3, label="Measured")

    ax.set_xlabel("Accumulated days", fontsize=8)
    ax.set_ylabel("Ohms", fontsize=8)
    ax.tick_params(labelsize=7)
    ax.ticklabel_format(style="plain", useOffset=False, axis="y")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=4, fontsize=7, frameon=False)
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def _decimals_for(nominal: float) -> int:
    """Decade-based decimal places, per spec: 0.1-1 Ohm: 8, 10 Ohm: 7,
    100 Ohm: 6, 1k: 5, 10k: 4, 100k: 3, 1M: 2, 10M: 1, 100M-1G: 0."""
    integer_digits = len(str(abs(int(nominal)))) if abs(nominal) >= 1 else 1
    return max(0, 9 - integer_digits)


def _format_ohms(value, nominal):
    if value is None:
        return "\u2014"
    return f"{value:,.{_decimals_for(nominal)}f}"


def _asset_flowables(detail: dict, styles) -> list:
    asset = detail["asset"]
    calibrations = detail["calibrations"]
    flow = []

    title = asset["model"] or asset["serial"]
    flow.append(Paragraph(f"<b>{escape(str(title))}</b>", styles["AssetTitle"]))
    flow.append(Paragraph(
        f"Serial {escape(str(asset['serial']))} &nbsp;\u00b7&nbsp; "
        f"Equipment ID {escape(str(asset['asset_number'] or '\u2014'))} "
        f"&nbsp;\u00b7&nbsp; Nominal {asset['nominal_ohms']:g} \u03a9 "
        f"&nbsp;\u00b7&nbsp; {escape(str(asset['source_sheet']))}",
        styles["AssetSub"],
    ))
    flow.append(Spacer(1, 6))

    if not calibrations:
        flow.append(Paragraph("No calibration history on file.", styles["Body"]))
        flow.append(Spacer(1, 14))
        flow.append(HRFlowable(width="100%", color=colors.HexColor("#dcdcd5"), thickness=0.5))
        flow.append(Spacer(1, 14))
        return flow

    has_trend = "predicted" in calibrations[0]
    if has_trend:
        png_bytes = _render_chart_png(calibrations, asset)
        flow.append(Image(io.BytesIO(png_bytes), width=4.6 * inch, height=2.23 * inch))
        flow.append(Spacer(1, 6))
    else:
        flow.append(Paragraph(
            f"Not enough calibration history for a trend yet "
            f"({len(calibrations)} points, need at least 4).", styles["Body"],
        ))

    latest = calibrations[-1]
    status_label, status_color = _status_of(latest)

    table_data = [
        ["Latest Cal", "Measured (\u03a9)", "MU (rel)", "Predicted", "Lower", "Upper", "Status"],
        [
            latest["date"],
            _format_ohms(latest["measured_value"], asset["nominal_ohms"]),
            f"{latest['mu_relative']:.2e}",
            _format_ohms(latest.get("predicted"), asset["nominal_ohms"]),
            _format_ohms(latest.get("lower"), asset["nominal_ohms"]),
            _format_ohms(latest.get("upper"), asset["nominal_ohms"]),
            status_label,
        ],
    ]
    t = Table(table_data, hAlign="LEFT", colWidths=[0.8*inch, 1.15*inch, 0.75*inch, 1.15*inch, 1.15*inch, 1.15*inch, 0.9*inch])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("TEXTCOLOR", (0, 0), (-1, 0), INK_DIM),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, colors.HexColor("#dcdcd5")),
        ("TEXTCOLOR", (6, 1), (6, 1), status_color),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    flow.append(t)

    if latest.get("reviewer_comment"):
        flow.append(Spacer(1, 4))
        flow.append(Paragraph(f"<i>Reviewer note: {escape(str(latest['reviewer_comment']))}</i>", styles["Comment"]))
    elif latest.get("reviewer_attachment_path"):
        flow.append(Spacer(1, 4))
        flow.append(Paragraph("<i>Reviewer note: Refer to the evaluation report</i>", styles["Comment"]))

    flow.append(Spacer(1, 14))
    flow.append(HRFlowable(width="100%", color=colors.HexColor("#dcdcd5"), thickness=0.5))
    flow.append(Spacer(1, 14))
    return flow


def _build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("AssetTitle", parent=styles["Heading2"], fontSize=13, spaceAfter=2))
    styles.add(ParagraphStyle("AssetSub", parent=styles["Normal"], fontSize=8.5,
                               textColor=colors.HexColor("#5c6773")))
    styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=9))
    styles.add(ParagraphStyle("Comment", parent=styles["Normal"], fontSize=8,
                               textColor=colors.HexColor("#5c6773")))
    return styles


def generate_report(conn, asset_ids: list, out_path: str) -> str:
    styles = _build_styles()
    doc = SimpleDocTemplate(
        out_path, pagesize=letter,
        leftMargin=0.6*inch, rightMargin=0.6*inch, topMargin=0.6*inch, bottomMargin=0.6*inch,
    )

    story = [
        Paragraph("Calibration Trending Report", styles["Title"]),
        Paragraph(f"Generated {datetime.now():%Y-%m-%d %H:%M}", styles["AssetSub"]),
        Spacer(1, 16),
    ]

    for asset_id in asset_ids:
        detail = get_asset_detail(conn, asset_id)
        if detail is None:
            continue
        story.extend(_asset_flowables(detail, styles))

    doc.build(story)
    return out_path
